package com.bdiplus.shoppingcart.util;

import com.bdiplus.shoppingcart.entity.ProductEntity;
import com.bdiplus.shoppingcart.model.Product;

import java.util.ArrayList;
import java.util.List;


public class ShoppingCartConverter {

    public static ProductEntity getProduct(Product product){
        ProductEntity productEntity = new ProductEntity();
        productEntity.setPrice(product.getPrice());
        productEntity.setName(product.getName());
        productEntity.setProductId(product.getId());
        return productEntity;
    }

    public static Product getProduct(ProductEntity productEntity){
        Product product = new Product();
        product.setPrice(productEntity.getPrice());
        product.setId(productEntity.getProductId());
        product.setName(productEntity.getName());
        return product;
    }

    public static ProductEntity updateProduct(Product product, ProductEntity productEntity){

        if (product.getName()!= null || !product.getName().equals("")){
            productEntity.setName(product.getName());
        }

        if (product.getPrice() != null){
            productEntity.setPrice(product.getPrice());
        }
        return productEntity;
    }

    public static List<Product> getProducts(List<ProductEntity> productEntityList){

        List<Product> products = new ArrayList<>();

        for(ProductEntity productEntity : productEntityList){
            products.add(getProduct(productEntity));
        }
        return products;
    }

}
