package com.bdiplus.shoppingcart.service;

import com.bdiplus.shoppingcart.entity.ProductEntity;
import com.bdiplus.shoppingcart.model.Product;
import com.bdiplus.shoppingcart.repository.ProductRepository;
import com.bdiplus.shoppingcart.util.ShoppingCartConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ShoppingCartService {

    @Autowired
    private ProductRepository productRepository;

    public Product createProduct (Product product) throws Exception{
        Optional<ProductEntity> productEntityOptional = productRepository.findByProductId(product.getId());
        if (productEntityOptional.isPresent()){
            throw new Exception("Product Already Exist");
        }
        ProductEntity productEntity = ShoppingCartConverter.getProduct(product);
        productRepository.save(productEntity);
        return product;

    }
    public Product updateProduct(Product product) throws Exception{
        Optional<ProductEntity> productEntityOptional = productRepository.findByProductId(product.getId());
        if (productEntityOptional.isEmpty()){
            throw new Exception("Product Does not exist");
        }
        ProductEntity productEntity = ShoppingCartConverter.updateProduct(product,productEntityOptional.get());
        productRepository.save(productEntity);
        return product;
    }
    public void deleteProduct(String productId) throws Exception{
        Optional<ProductEntity> productEntityOptional = productRepository.findByProductId(productId);
        if (productEntityOptional.isEmpty()){
            throw new Exception("Product Does not exist");
        }
        productRepository.delete(productEntityOptional.get());
    }

    public List<Product> getProducts (){
        List<ProductEntity> productEntityList = productRepository.findAll();
        return ShoppingCartConverter.getProducts(productEntityList);
    }
}
