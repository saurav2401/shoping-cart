package com.bdiplus.shoppingcart.controller;

import com.bdiplus.shoppingcart.model.Product;
import com.bdiplus.shoppingcart.model.Status;
import com.bdiplus.shoppingcart.service.ShoppingCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ShoppingCartController {

    @Autowired
    private ShoppingCartService shoppingCartService;


    @PostMapping("/create/product")
    public Status createProduct(@RequestBody Product product){
        Status status = new Status();
        try {
            shoppingCartService.createProduct(product);
            status.setCode(200);
            status.setMessage("Product Created SuccessFully");
        } catch (Exception e) {
            status.setCode(300);
            status.setMessage(e.getMessage());
        }
        return status;
    }

    @GetMapping("/all/product")
    public List<Product> getAllProducts(){
        return shoppingCartService.getProducts();
    }

    @PutMapping("/update/product")
    public Status updateProduct(@RequestBody Product product){
        Status status = new Status();
        try {
            shoppingCartService.updateProduct(product);
            status.setCode(200);
            status.setMessage("Product Updated SuccessFully");
        } catch (Exception e) {
            status.setCode(300);
            status.setMessage(e.getMessage());
        }
        return status;
    }

    @DeleteMapping("/delete/product/{productId}")
    public Status deleteProduct(@PathVariable("productId") String productId){
        Status status = new Status();
        try {
            shoppingCartService.deleteProduct(productId);
            status.setCode(200);
            status.setMessage("Product Deleted SuccessFully");
        } catch (Exception e) {
            status.setCode(300);
            status.setMessage(e.getMessage());
        }
        return status;
    }

}
