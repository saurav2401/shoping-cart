package com.bdiplus.shoppingcart.model;

import lombok.Data;

@Data
public class Status {
    private int code;
    private String message;
}
